create view contractview as
select `freelance_db`.`contract`.`id`         AS `contractid`,
       `freelance_db`.`contract`.`jobappid`   AS `jobappid`,
       `freelance_db`.`contract`.`dos`        AS `condos`,
       `freelance_db`.`contract`.`dof`        AS `condof`,
       `freelance_db`.`contract`.`status`     AS `constatus`,
       `freelance_db`.`job_app`.`freelanceid` AS `freelanceid`,
       `freelance_db`.`jobs`.`clientid`       AS `clientid`,
       `freelance_db`.`jobs`.`price`          AS `price`,
       `freelance_db`.`userinfo`.`fullname`   AS `freelancename`,
       `freelance_db`.`userinfo`.`fullname`   AS `clientname`
from (((`freelance_db`.`contract` left join `freelance_db`.`job_app` on (`freelance_db`.`contract`.`jobappid` = `freelance_db`.`job_app`.`id`)) left join `freelance_db`.`jobs` on (`freelance_db`.`job_app`.`jobid` = `freelance_db`.`jobs`.`id`))
         left join `freelance_db`.`userinfo`
                   on (`freelance_db`.`job_app`.`freelanceid` = `freelance_db`.`userinfo`.`id` and
                       `freelance_db`.`jobs`.`clientid` = `freelance_db`.`userinfo`.`id`))
group by `freelance_db`.`contract`.`id`;

