create view userview as
select `freelance_db`.`useraccount`.`id`       AS `id`,
       `freelance_db`.`useraccount`.`userid`   AS `userid`,
       `freelance_db`.`useraccount`.`username` AS `username`,
       `freelance_db`.`useraccount`.`password` AS `password`,
       `freelance_db`.`userinfo`.`fullname`    AS `fullname`,
       `freelance_db`.`userinfo`.`gender`      AS `gender`,
       `freelance_db`.`userinfo`.`email`       AS `email`,
       `freelance_db`.`userinfo`.`mobile`      AS `mobile`,
       `freelance_db`.`userinfo`.`address`     AS `address`,
       `freelance_db`.`userinfo`.`city`        AS `city`,
       `freelance_db`.`userinfo`.`dor`         AS `dor`,
       `freelance_db`.`role`.`name`            AS `role`
from ((`freelance_db`.`useraccount` left join `freelance_db`.`userinfo` on (`freelance_db`.`useraccount`.`userid` =
                                                                            `freelance_db`.`userinfo`.`id`))
         left join `freelance_db`.`role` on (`freelance_db`.`useraccount`.`role` = `freelance_db`.`role`.`id`));

