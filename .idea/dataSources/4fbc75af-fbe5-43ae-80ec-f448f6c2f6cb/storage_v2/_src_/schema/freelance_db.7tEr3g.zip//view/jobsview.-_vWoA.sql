create view jobsview as
select `freelance_db`.`jobs`.`id`                    AS `jobid`,
       `freelance_db`.`jobs`.`clientid`              AS `clientid`,
       `freelance_db`.`jobs`.`title`                 AS `title`,
       `freelance_db`.`jobs`.`details`               AS `details`,
       `freelance_db`.`jobs`.`timelength`            AS `timelength`,
       `freelance_db`.`jobs`.`price`                 AS `price`,
       `freelance_db`.`jobs`.`skills`                AS `skills`,
       `freelance_db`.`jobs`.`dop`                   AS `dop`,
       `freelance_db`.`jobs`.`tags`                  AS `tags`,
       `freelance_db`.`userinfo`.`fullname`          AS `clientname`,
       count(distinct `freelance_db`.`job_app`.`id`) AS `noa`
from ((`freelance_db`.`jobs` left join `freelance_db`.`job_app` on (`freelance_db`.`jobs`.`id` = `freelance_db`.`job_app`.`jobid`))
         left join `freelance_db`.`userinfo` on (`freelance_db`.`jobs`.`clientid` = `freelance_db`.`userinfo`.`id`))
group by `freelance_db`.`jobs`.`id`;

